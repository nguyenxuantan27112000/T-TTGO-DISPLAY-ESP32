# c-qrcode-bitmap
Generate QR code as bitmap image basing on given text
