﻿#include <stdio.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "qrcodegen.h"
#include "worker.h"
#include <locale.h>
#include <wchar.h>


// The main application program.
int main(void) {
    char fileName[50];
	strcpy(fileName, "qrcode_test.bmp");
    // const char* fileName = "b/qrcode.bmp"; // path where file will be saved
    int pixelPerQuadrant = 4; // set pixels count per item
    const char* text = "Hello"; //text to be encoded
    // Size: 100
    printQRCode(fileName, pixelPerQuadrant, text);
    printf("%s\r\n", text);
	return EXIT_SUCCESS;
}
